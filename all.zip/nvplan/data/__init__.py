"""Illustrative (dummy) data generation."""
